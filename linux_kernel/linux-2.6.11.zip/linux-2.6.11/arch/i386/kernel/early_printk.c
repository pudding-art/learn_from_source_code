
#include "../../x86_64/kernel/early_printk.c"
