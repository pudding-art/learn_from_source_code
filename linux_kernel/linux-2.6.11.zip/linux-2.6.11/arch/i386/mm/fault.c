/*
 *  linux/arch/i386/mm/fault.c
 *
 *  Copyright (C) 1995  Linus Torvalds
 */

#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/types.h>
#include <linux/ptrace.h>
#include <linux/mman.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/smp_lock.h>
#include <linux/interrupt.h>
#include <linux/init.h>
#include <linux/tty.h>
#include <linux/vt_kern.h>		/* For unblank_screen() */
#include <linux/highmem.h>
#include <linux/module.h>

#include <asm/system.h>
#include <asm/uaccess.h>
#include <asm/desc.h>
#include <asm/kdebug.h>

extern void die(const char *,struct pt_regs *,long);

/*
 * Unlock any spinlocks which will prevent us from getting the
 * message out 
 */
void bust_spinlocks(int yes)
{
	int loglevel_save = console_loglevel;

	if (yes) {
		oops_in_progress = 1;
		return;
	}
#ifdef CONFIG_VT
	unblank_screen();
#endif
	oops_in_progress = 0;
	/*
	 * OK, the message is on the console.  Now we call printk()
	 * without oops_in_progress set so that printk will give klogd
	 * a poke.  Hold onto your hats...
	 */
	console_loglevel = 15;		/* NMI oopser may have shut the console up */
	printk(" ");
	console_loglevel = loglevel_save;
}

/*
 * Return EIP plus the CS segment base.  The segment limit is also
 * adjusted, clamped to the kernel/user address space (whichever is
 * appropriate), and returned in *eip_limit.
 *
 * The segment is checked, because it might have been changed by another
 * task between the original faulting instruction and here.
 *
 * If CS is no longer a valid code segment, or if EIP is beyond the
 * limit, or if it is a kernel address when CS is not a kernel segment,
 * then the returned value will be greater than *eip_limit.
 * 
 * This is slow, but is very rarely executed.
 */
static inline unsigned long get_segment_eip(struct pt_regs *regs,
					    unsigned long *eip_limit)
{
	unsigned long eip = regs->eip;
	unsigned seg = regs->xcs & 0xffff;
	u32 seg_ar, seg_limit, base, *desc;

	/* The standard kernel/user address space limit. */
	*eip_limit = (seg & 3) ? USER_DS.seg : KERNEL_DS.seg;

	/* Unlikely, but must come before segment checks. */
	if (unlikely((regs->eflags & VM_MASK) != 0))
		return eip + (seg << 4);
	
	/* By far the most common cases. */
	if (likely(seg == __USER_CS || seg == __KERNEL_CS))
		return eip;

	/* Check the segment exists, is within the current LDT/GDT size,
	   that kernel/user (ring 0..3) has the appropriate privilege,
	   that it's a code segment, and get the limit. */
	__asm__ ("larl %3,%0; lsll %3,%1"
		 : "=&r" (seg_ar), "=r" (seg_limit) : "0" (0), "rm" (seg));
	if ((~seg_ar & 0x9800) || eip > seg_limit) {
		*eip_limit = 0;
		return 1;	 /* So that returned eip > *eip_limit. */
	}

	/* Get the GDT/LDT descriptor base. 
	   When you look for races in this code remember that
	   LDT and other horrors are only used in user space. */
	if (seg & (1<<2)) {
		/* Must lock the LDT while reading it. */
		down(&current->mm->context.sem);
		desc = current->mm->context.ldt;
		desc = (void *)desc + (seg & ~7);
	} else {
		/* Must disable preemption while reading the GDT. */
		desc = (u32 *)&per_cpu(cpu_gdt_table, get_cpu());
		desc = (void *)desc + (seg & ~7);
	}

	/* Decode the code segment base from the descriptor */
	base = get_desc_base((unsigned long *)desc);

	if (seg & (1<<2)) { 
		up(&current->mm->context.sem);
	} else
		put_cpu();

	/* Adjust EIP and segment limit, and clamp at the kernel limit.
	   It's legitimate for segments to wrap at 0xffffffff. */
	seg_limit += base;
	if (seg_limit < *eip_limit && seg_limit >= base)
		*eip_limit = seg_limit;
	return eip + base;
}

/* 
 * Sometimes AMD Athlon/Opteron CPUs report invalid exceptions on prefetch.
 * Check that here and ignore it.
 */
static int __is_prefetch(struct pt_regs *regs, unsigned long addr)
{ 
	unsigned long limit;
	unsigned long instr = get_segment_eip (regs, &limit);
	int scan_more = 1;
	int prefetch = 0; 
	int i;

	for (i = 0; scan_more && i < 15; i++) { 
		unsigned char opcode;
		unsigned char instr_hi;
		unsigned char instr_lo;

		if (instr > limit)
			break;
		if (__get_user(opcode, (unsigned char *) instr))
			break; 

		instr_hi = opcode & 0xf0; 
		instr_lo = opcode & 0x0f; 
		instr++;

		switch (instr_hi) { 
		case 0x20:
		case 0x30:
			/* Values 0x26,0x2E,0x36,0x3E are valid x86 prefixes. */
			scan_more = ((instr_lo & 7) == 0x6);
			break;
			
		case 0x60:
			/* 0x64 thru 0x67 are valid prefixes in all modes. */
			scan_more = (instr_lo & 0xC) == 0x4;
			break;		
		case 0xF0:
			/* 0xF0, 0xF2, and 0xF3 are valid prefixes */
			scan_more = !instr_lo || (instr_lo>>1) == 1;
			break;			
		case 0x00:
			/* Prefetch instruction is 0x0F0D or 0x0F18 */
			scan_more = 0;
			if (instr > limit)
				break;
			if (__get_user(opcode, (unsigned char *) instr)) 
				break;
			prefetch = (instr_lo == 0xF) &&
				(opcode == 0x0D || opcode == 0x18);
			break;			
		default:
			scan_more = 0;
			break;
		} 
	}
	return prefetch;
}

static inline int is_prefetch(struct pt_regs *regs, unsigned long addr,
			      unsigned long error_code)
{
	if (unlikely(boot_cpu_data.x86_vendor == X86_VENDOR_AMD &&
		     boot_cpu_data.x86 >= 6)) {
		/* Catch an obscure case of prefetch inside an NX page. */
		if (nx_enabled && (error_code & 16))
			return 0;
		return __is_prefetch(regs, addr);
	}
	return 0;
} 

fastcall void do_invalid_op(struct pt_regs *, unsigned long);

/*
 * This routine handles page faults.  It determines the address,
 * and the problem, and then passes it off to one of the appropriate
 * routines.
 *
 * 找个例程处理缺页。它检查虚拟地址和问题，然后传递它给一个合适的例程处理。
 * error_code:
 *	bit 0 == 0 means no page found, 1 means protection fault
 *  0位为 0 页没有找到，1 权限错误
 *	bit 1 == 0 means read, 1 means write
 *  1位为 0 读缺页 1 写缺页
 *	bit 2 == 0 means kernel, 1 means user-mode
 *  2位为 0 内核态缺页 1 用户态缺页
 */
enum x86_pf_error_code {
    
    PF_PROT		=		1 << 0,/**<0: no page found	1: protection fault*/
    PF_WRITE	=		1 << 1,/**<0: read access		1: write access*/
    PF_USER		=		1 << 2,/**<0: kernel-mode access	1: user-mode access*/
};

static noinline int vmalloc_fault(unsigned long address)
{
	/*
	 * Synchronize this task's top level page-table
	 * with the 'reference' page table.
	 *
	 * Do _not_ use "tsk" here. We might be inside
	 * an interrupt in the middle of a task switch..
	 */
	int index = pgd_index(address);
	unsigned long pgd_paddr;
	pgd_t *pgd, *pgd_k;
	pud_t *pud, *pud_k;
	pmd_t *pmd, *pmd_k;
	pte_t *pte_k;
	
	/*缺页异常的pgd，不从current中获取，是因为在进程切换期间都可能发生此类缺页*/
	asm("movl %%cr3,%0":"=r" (pgd_paddr));
	pgd = (pgd_t *)__va(pgd_paddr) + index;
	pgd_k = init_mm.pgd + index;

	if (!pgd_present(*pgd_k)) {
		/*内核没有正确的初始化内核页表*/
		return -1;
	}

	/*
	 * set_pgd(pgd, *pgd_k); here would be useless on PAE
	 * and redundant with the set_pmd() on non-PAE. As would
	 * set_pud.
	 */

	pud = pud_offset(pgd, address);
	pud_k = pud_offset(pgd_k, address);
	if (!pud_present(*pud_k))
        return -1;
    
	pmd = pmd_offset(pud, address);
	pmd_k = pmd_offset(pud_k, address);
	if (!pmd_present(*pmd_k))
        return -1;
	
	/*直接共享pte_t页表页，而不增加引用*/
	set_pmd(pmd, *pmd_k);

	pte_k = pte_offset_kernel(pmd_k, address);
    //判断是否有page页，有可能vmalloc()并没有为该地址分配页
	if (!pte_present(*pte_k))
        return -1;
    
	return 0;
}


fastcall void do_page_fault(struct pt_regs *regs, unsigned long error_code)
{
	struct task_struct *tsk;
	struct mm_struct *mm;
	struct vm_area_struct * vma;
	unsigned long address;
	unsigned long page;
	int write;
	siginfo_t info;

	/* get the address 从CR2中获取缺页时的虚拟地址 */
	__asm__("movl %%cr2,%0":"=r" (address));

    /*回调注册的通知例程*/
	if (notify_die(DIE_PAGE_FAULT, "page fault", regs, error_code, 14,
					SIGSEGV) == NOTIFY_STOP)
		return;
	/* It's safe to allow irq's after cr2 has been saved */
	if (regs->eflags & (X86_EFLAGS_IF|VM_MASK))
		local_irq_enable();

	tsk = current;

	info.si_code = SEGV_MAPERR;

	/*
	 * We fault-in kernel-space virtual memory on-demand. The
	 * 'reference' page table is init_mm.pgd.
	 *
	 * NOTE! We MUST NOT take any locks for this case. We may
	 * be in an interrupt or a critical region, and should
	 * only copy the information from the master page table,
	 * nothing more.
	 *
	 * This verifies that the fault happens in kernel space
	 * (error_code & 4) == 0, and that the fault was not a
	 * protection error (error_code & 1) == 0.
     * 我们缺页在内核空间的虚拟地址上。相关的页表是init_mm.pgd.
     * 注意对于这样的情况，我们不必去获取任何锁。
	 * 我们可能在中断中或一个关键区域，
     * 所以应该仅从主页表中拷贝信息，仅此而已。
	 */
	if (unlikely(address >= TASK_SIZE)) { //地址属于内核空间
		if (!(error_code & (PF_PROT | PF_USER)/*101*/))//内核态，且缺页
			if (!vmalloc_fault(address))
                return;
		/* 
		 * Don't take the mm semaphore here. If we fixup a prefetch
		 * fault we could otherwise deadlock.
         * 1. 用户态访问了内核地址空间
         * 2. 内核态访问了保护地址空间
		 */
		goto bad_area_nosemaphore;
	} 

	mm = tsk->mm;

	/*
	 * If we're in an interrupt, have no user context or are running in an
	 * atomic region then we must not take the fault..
     * 如果我们在一个中断中，没用用户上下文（内核线程）或运行在一个原子的区域里，
	 * 则我们一定不能处理这个缺页。
	 */
	if (in_atomic() || !mm)
        /*
         * 1. 禁用调度，然后缺页
         * 2. 内核线程访问了用户空间
         */
		goto bad_area_nosemaphore;

	/* When running in the kernel we expect faults to occur only to
	 * addresses in user space.  All other faults represent errors in the
	 * kernel and should generate an OOPS.  Unfortunatly, in the case of an
	 * erroneous fault occuring in a code path which already holds mmap_sem
	 * we will deadlock attempting to validate the fault against the
	 * address space.  Luckily the kernel only validly references user
	 * space from well defined areas of code, which are listed in the
	 * exceptions table.
	 *
	 * 当我们运行在内核态，我们期望仅对用户态地址产生缺页异常（除上面的vmalloc()缺页）。
     * 其他所有的在内核态的缺页都是表示是错误的，应该产生OOPS。
     * 不幸是，在错误的缺页产生在已经持有mmap_sem的情况下，试图去对地址验证缺页，我们会死锁。
     * 幸运的是内核仅有效的引用用户空间，从我们定义好的代码区域，这些区域被列在异常表中。
	 *
	 * As the vast majority of faults will be valid we will only perform
	 * the source reference check when there is a possibilty of a deadlock.
	 * Attempt to lock the address space, if we cannot we then validate the
	 * source.  If this is invalid we can skip the address space check,
	 * thus avoiding the deadlock.
     *
     * 由于绝大多数缺页异常都是有效的，当有一个死锁的可能性时，我们仅执行原引用检查。
     * 试图锁住地址空间，如果我们不能做到，我们则使原有效。如果这是无效的，我们可以
     * 跳过地址空间检测，这样可以避免死锁。
	 */
	if (!down_read_trylock(&mm->mmap_sem)) {
        /* 不能获取到锁，且为内核态缺页，则检查异常表，失败则缺页处理失败。
		 * 可能引起缺页的地方都是可以预见的，通常是错误的系统调用参数引起的。
		 */
		if ((error_code & PF_USER) == 0 &&
		    !search_exception_tables(regs->eip))
			goto bad_area_nosemaphore;
        /*非内核态缺页，则可以阻塞的获取锁*/
		down_read(&mm->mmap_sem);
	}

    /* 查找第一个大于address的vma*/
	vma = find_vma(mm, address);
	/*address < vma->vm_end*/
	if (!vma)
		goto bad_area; /*错误的地址*/
	if (vma->vm_start <= address)
		goto good_area;/*有效的地址映射，且不是栈缺页*/
	if (!(vma->vm_flags & VM_GROWSDOWN))
		goto bad_area;/* 栈缺页，必须是向低地址扩展的，
                       *（带有自动扩展的属性，就可以自动扩展，然后挂页？）
                       */
	if (error_code & PF_USER) {
		/*
		 * accessing the stack below %esp is always a bug.
		 * The "+ 32" is there due to some instructions (like
		 * pusha) doing post-decrement on the stack and that
		 * doesn't show up until later..
         *
         * 浏览栈顶指针之下的地方总是一个Bug。
         * 但是有些指令会访问栈指针下的一些空间（指令缺页？），但是不会超过32个字节。
         * 判断缺页的地址是否满足栈的特性
		 */
		if (address + 32 < regs->esp)
			goto bad_area;
	}
    /*扩展栈， address < vma->vm_start*/
	if (expand_stack(vma, address))
		goto bad_area;
/*
 * Ok, we have a good vm_area for this memory access, so
 * we can handle it..
 */
good_area:
	info.si_code = SEGV_ACCERR;
	write = 0;
    /*查看保护位和读写位的情况，确认缺页细节*/
	switch (error_code & (PF_PROT | PF_WRITE)) {
		default:	/* 3: 写保护，权限异常，write, present */
#ifdef TEST_VERIFY_AREA
			if (regs->cs == KERNEL_CS)
				printk("WP fault at %08lx\n", regs->eip);
#endif
			/* fall through */
		case PF_WRITE:		/* 写缺页，缺页异常，write, not present */
			if (!(vma->vm_flags & VM_WRITE))
				goto bad_area;//没有权限
			write++;
			break;
		case PF_PROT:		/* 读保护，权限异常，read, present */
			goto bad_area;
		case 0:		/* 读缺页，缺页异常，read, not present */
			if (!(vma->vm_flags & (VM_READ | VM_EXEC)))
				goto bad_area;
	}

 survive:
	/*
	 * If for any reason at all we couldn't handle the fault,
	 * make sure we exit gracefully rather than endlessly redo
	 * the fault.
     * 如果因为某些原因，我们根本不能处理这个缺页，必须保证我们能优雅的退出，
     * 而不是无休止的重新触发这个缺页。
	 */
	switch (handle_mm_fault(mm, vma, address, write)) {
		case VM_FAULT_MINOR://次要缺页,未发生阻塞就处理了缺页
			tsk->min_flt++;
			break;
		case VM_FAULT_MAJOR://主要缺页,发生了睡眠或从磁盘读取的数据等才处理好缺页
			tsk->maj_flt++;
			break;
		case VM_FAULT_SIGBUS://总线错误,不是由于内存不足而处理失败的其他情况
			goto do_sigbus;
		case VM_FAULT_OOM://内存不足,不能分配页框导致处理失败。
			goto out_of_memory;
		default:
			BUG();
	}

	/*
	 * Did it hit the DOS screen memory VA from vm86 mode?
	 */
	if (regs->eflags & VM_MASK) {
		unsigned long bit = (address - 0xA0000) >> PAGE_SHIFT;
		if (bit < 32)
			tsk->thread.screen_bitmap |= 1 << bit;
	}
	up_read(&mm->mmap_sem);
	return;

/*
 * Something tried to access memory that isn't in our memory map..
 * Fix it, but check if it's kernel or user first..
 */
bad_area:
	up_read(&mm->mmap_sem);

bad_area_nosemaphore:
	/* User mode accesses just cause a SIGSEGV */
    // 段错误处理
	if (error_code & PF_USER) {//用户态
		/* 
		 * Valid to do another page fault here because this one came 
		 * from user space.
         * 因为预读产生的缺页，所以可以再次触发该缺页
		 */
		if (is_prefetch(regs, address, error_code))
			return;

		tsk->thread.cr2 = address;
		/* Kernel addresses are always protection faults
         * 如果用户态访问了，内核地址空间，将错误码添上 protection fault (最低位为1）*/
		tsk->thread.error_code = error_code | (address >= TASK_SIZE);
		tsk->thread.trap_no = 14;
		info.si_signo = SIGSEGV;
		info.si_errno = 0;
		/* info.si_code has been set above */
		info.si_addr = (void __user *)address;
		force_sig_info(SIGSEGV, &info, tsk);
		return;
	}

#ifdef CONFIG_X86_F00F_BUG
	/*
	 * Pentium F0 0F C7 C8 bug workaround.
	 */
	if (boot_cpu_data.f00f_bug) {
		unsigned long nr;
		
		nr = (address - idt_descr.address) >> 3;

		if (nr == 6) {
			do_invalid_op(regs, 0);
			return;
		}
	}
#endif

no_context://内核态缺页处理
	{
        //内核态将产生Oop
		/* Are we prepared to handle this kernel fault?  */
		if (fixup_exception(regs))
			return;
		
		/*
		 * Valid to do another page fault here, because if this fault
		 * had been triggered by is_prefetch fixup_exception would have
		 * handled it.
		 */
        if (is_prefetch(regs, address, error_code))
	      	return;
		
		/*
		 * Oops. The kernel tried to access some bad page. We'll have to
		 * terminate things with extreme prejudice.
		 */
		
		bust_spinlocks(1);
		
#ifdef CONFIG_X86_PAE
		if (error_code & 16) {
			pte_t *pte = lookup_address(address);
			
			if (pte && pte_present(*pte) && !pte_exec_kernel(*pte))
				printk(KERN_CRIT "kernel tried to execute NX-protected page "
					   "- exploit attempt? (uid: %d)\n", current->uid);
		}
#endif
		if (address < PAGE_SIZE)
			printk(KERN_ALERT "Unable to handle kernel NULL pointer dereference");
		else
			printk(KERN_ALERT "Unable to handle kernel paging request");
		printk(" at virtual address %08lx\n",address);
		printk(KERN_ALERT " printing eip:\n");
		printk("%08lx\n", regs->eip);
        //获取当前页表目录的虚拟地址
		asm("movl %%cr3,%0":"=r" (page));
		page = ((unsigned long *) __va(page))[address >> 22];
        //打印pgd的位置中的项值
		printk(KERN_ALERT "*pde = %08lx\n", page);
		/*
		 * We must not directly access the pte in the highpte
		 * case, the page table might be allocated in highmem.
		 * And lets rather not kmap-atomic the pte, just in case
		 * it's allocated already.
		 */
#ifndef CONFIG_HIGHPTE
		if (page & 1) { /* page 为 页表项 pmd_t 的值，低12位为页表标志
				* 第一位表示 _PAGE_PRESENT，页已分配*/
			page &= PAGE_MASK;
			address &= 0x003ff000;
			page = ((unsigned long *) __va(page))[address >> PAGE_SHIFT];
			printk(KERN_ALERT "*pte = %08lx\n", page);
		}
#endif
		die("Oops", regs, error_code);
		bust_spinlocks(0);
		do_exit(SIGKILL);
	}

/*
 * We ran out of memory, or some other thing happened to us that made
 * us unable to handle the page fault gracefully.
 */
out_of_memory://内存不足
	{
		up_read(&mm->mmap_sem);
		if (tsk->pid == 1) {
            // 如果是init进程缺页，休眠一会，继续尝试
			yield();
			down_read(&mm->mmap_sem);
			goto survive;
		}
		printk("VM: killing process %s\n", tsk->comm);
		if (error_code & PF_USER)
			do_exit(SIGKILL);//用户进程，直接Kill
		goto no_context;//内核线程，Oop
	}

do_sigbus://总线错误
	{
		up_read(&mm->mmap_sem);
		
		/* Kernel mode? Handle exceptions or die */
		if (!(error_code & PF_USER))
			goto no_context;
		
		/* User space => ok to do another page fault */
		if (is_prefetch(regs, address, error_code))
			return;
		
		tsk->thread.cr2 = address;
		tsk->thread.error_code = error_code;
		tsk->thread.trap_no = 14;
		info.si_signo = SIGBUS;
		info.si_errno = 0;
		info.si_code = BUS_ADRERR;
		info.si_addr = (void __user *)address;
		force_sig_info(SIGBUS, &info, tsk);
		return;
	}
	
    return;
}
