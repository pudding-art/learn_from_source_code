/*
 * Written by: Patricia Gaughen <gone@us.ibm.com>, IBM Corporation
 * August 2002: added remote node KVA remap - Martin J. Bligh 
 *
 * Copyright (C) 2002, IBM Corp.
 *
 * All rights reserved.          
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, GOOD TITLE or
 * NON INFRINGEMENT.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <linux/config.h>
#include <linux/mm.h>
#include <linux/bootmem.h>
#include <linux/mmzone.h>
#include <linux/highmem.h>
#include <linux/initrd.h>
#include <linux/nodemask.h>
#include <asm/e820.h>
#include <asm/setup.h>
#include <asm/mmzone.h>
#include <bios_ebda.h>

struct pglist_data *node_data[MAX_NUMNODES];
bootmem_data_t node0_bdata;

/*
 * numa interface - we expect the numa architecture specfic code to have
 *                  populated the following initialisation.
 *
 * 1) node_online_map  - the map of all nodes configured (online) in the system
 * 2) physnode_map     - the mapping between a pfn and owning node
 * 3) node_start_pfn   - the starting page frame number for a node
 * 3) node_end_pfn     - the ending page fram number for a node
 */

/*
 * physnode_map keeps track of the physical memory layout of a generic
 * numa node on a 256Mb break (each element of the array will
 * represent 256Mb of memory and will be marked by the node id.  so,
 * if the first gig is on node 0, and the second gig is on node 1
 * physnode_map will contain:
 *
 *     physnode_map[0-3] = 0;
 *     physnode_map[4-7] = 1;
 *     physnode_map[8- ] = -1;
 */
s8 physnode_map[MAX_ELEMENTS] = { [0 ... (MAX_ELEMENTS - 1)] = -1}; /**<下标对应页帧号范围（ [idx ~ (idx + 1)] * PAGES_PER_ELEMENT)，存储该页帧所属的节点号*/

/*启动过程中节点中原本的页帧数，会除开管理内存所需的内存空间后而变化*/
unsigned long node_start_pfn[MAX_NUMNODES];/**<下标对应节点id，存储该节点可用于分配的起始页帧号*/
unsigned long node_end_pfn[MAX_NUMNODES];/**<下标对应节点id，存储该节点可用于分配的结束页帧号
	* 除node0，其他node的page描述符都存在各自管理的物理内存最后面
	*/

extern unsigned long find_max_low_pfn(void);
extern void find_max_pfn(void);
extern void one_highpage_init(struct page *, int, int);

extern struct e820map e820;
extern unsigned long init_pg_tables_end;
extern unsigned long highend_pfn, highstart_pfn;
extern unsigned long max_low_pfn;
extern unsigned long totalram_pages;
extern unsigned long totalhigh_pages;

#define LARGE_PAGE_BYTES (PTRS_PER_PTE * PAGE_SIZE)//4MB
/*内核会在每个节点的后面位置选取一个对齐pmd映射内存大小的页帧数用于该节点的管理内存空间*/
unsigned long node_remap_start_pfn[MAX_NUMNODES];/**<每个下标对应保留页帧的起始页帧号*/
unsigned long node_remap_size[MAX_NUMNODES];/**<对应下标存储管理该节点内的页帧的内存结构所需的页帧数，保留页帧数*/
unsigned long node_remap_offset[MAX_NUMNODES];/**<每个下标对应当前保留页帧数的累加值*/
void *node_remap_start_vaddr[MAX_NUMNODES];/*每个下标对应该节点保留页帧的起始虚拟地址*/
void set_pmd_pfn(unsigned long vaddr, unsigned long pfn, pgprot_t flags);

/*
 * FLAT - support for basic PC memory model with discontig enabled, essentially
 *        a single node with all available processors in it with a flat
 *        memory map.
 */
int __init get_memcfg_numa_flat(void)
{
	printk("NUMA - single node, flat memory mode\n");

	/* Run the memory configuration and find the top of memory. */
	find_max_pfn();
	node_start_pfn[0] = 0;
	node_end_pfn[0] = max_pfn;

        /* Indicate there is one node available. */
	nodes_clear(node_online_map);
	node_set_online(0);
	return 1;
}

/*
 * Find the highest page frame number we have available for the node
 */
static void __init find_max_pfn_node(int nid)
{
	if (node_end_pfn[nid] > max_pfn)
		node_end_pfn[nid] = max_pfn;
	/*
	 * if a user has given mem=XXXX, then we need to make sure 
	 * that the node _starts_ before that, too, not just ends
	 * 使用了参数启动，页帧号起始可能相等
	 */
	if (node_start_pfn[nid] > max_pfn)
		node_start_pfn[nid] = max_pfn;
	if (node_start_pfn[nid] > node_end_pfn[nid])
		BUG();
}

/* 
 * Allocate memory for the pg_data_t for this node via a crude pre-bootmem
 * method.  For node zero take this from the bottom of memory, for
 * subsequent nodes place them at node_remap_start_vaddr which contains
 * node local data in physically node local memory.  See setup_memory()
 * for details.
 */
static void __init allocate_pgdat(int nid)
{
	if (nid) {
		/*非0 NODE 的NODE数据结构位于 紧接高端内存之下 （尚未挂页，不可访问）*/
		NODE_DATA(nid) = (pg_data_t *)node_remap_start_vaddr[nid];
	} else {
		/*0 NODE 的NODE数据结构位于 紧接低端内存之上 （已挂页，可访问）*/
		NODE_DATA(nid) = (pg_data_t *)(__va(min_low_pfn << PAGE_SHIFT));
		min_low_pfn += PFN_UP(sizeof(pg_data_t));
	}
}

/*
 * Register fully available low RAM pages with the bootmem allocator.
 * @param system_max_low_pfn 启动内存分配器所管理内存的结束页帧号
 * 扫描可用的页帧
 */
static void __init register_bootmem_low_pages(unsigned long system_max_low_pfn)
{
	int i;

	for (i = 0; i < e820.nr_map; i++) {
		unsigned long curr_pfn, last_pfn, size;
		/*
		 * Reserve usable low memory
		 */
		if (e820.map[i].type != E820_RAM)
			continue;
		/*
		 * We are rounding up the start address of usable memory:
		 */
		curr_pfn = PFN_UP(e820.map[i].addr);
		if (curr_pfn >= system_max_low_pfn)
			continue;
		/*
		 * ... and at the end of the usable range downwards:
		 */
		last_pfn = PFN_DOWN(e820.map[i].addr + e820.map[i].size);

		if (last_pfn > system_max_low_pfn)
			last_pfn = system_max_low_pfn;

		/*
		 * .. finally, did all the rounding and playing
		 * around just make the area go away?
		 */
		if (last_pfn <= curr_pfn)
			continue;

		size = last_pfn - curr_pfn;
		free_bootmem_node(NODE_DATA(0), PFN_PHYS(curr_pfn), PFN_PHYS(size));
	}
}

/**
 * 将用于各个节点（除0节点外）的节点管理的页帧挂载到非直接映射虚拟地址的起始处
 * 每个NODE的后半部分的页帧用于自身拥有的页帧的的管理和描述
 */
void __init remap_numa_kva(void)
{
	void *vaddr;
	unsigned long pfn;
	int node;

	for_each_online_node(node) {
		if (node == 0)
			continue;
		/*按PMD大小（4MB）偏移页帧号，并将页帧号映射为4MB的巨型页*/
		for (pfn=0; pfn < node_remap_size[node]; pfn += PTRS_PER_PTE) {
			/*每个NODE管理内存的起始虚地址都是按PMD大小对齐的*/
			vaddr = node_remap_start_vaddr[node]+(pfn<<PAGE_SHIFT);
			set_pmd_pfn((ulong) vaddr, 
				node_remap_start_pfn[node] + pfn, /*该虚拟地址对应页帧号*/
				PAGE_KERNEL_LARGE);
		}
	}
}
/*
 *                                      old node_end_pfn[1]
 *         +-----------------------------+----------------+-----------------+
 *         |            Node1            |    Node2       |     Node3       |
 *         +-----------------------------+----------------+-----------------+
 *         |----------|//////////////////|--------|///////|---------|///////|
 *         +----------+------------------+----------------+-----------------+
 *         |          |node_remap_size[1]|
 *         |          |pgtable belong this pg_data_t and all of pages can mapping into one pmd
 * node_start_pfn[1]  |
 *                    |
 *     new node_end_pfn[1]
 *         node_remap_start_pfn[1]
 *
 * 以下用于计算将用于各个节点内存管理单元物理地址映射到虚地址的偏移
 * node_remap_offset[1] = 50 number of pages belong to manager data struct of node1
 * node_remap_offset[2] = 100
 * node_remap_offset[3] = 150
 */
static unsigned long calculate_numa_remap_pages(void)
{
	int nid;
	unsigned long size, reserve_pages = 0;

	for_each_online_node(nid) {
        /*不计算启动时的node，这个node的描述符固定位置*/
		if (nid == 0)
			continue;
		/* calculate the size of the mem_map needed in bytes */
		/*
		 * 计算管理每个节点需要的页帧描述符和节点描述符的内存空间
         * 每个节点的尾部页帧用于管理页帧
		 */
		size = (node_end_pfn[nid] - node_start_pfn[nid] + 1)
			* sizeof(struct page) + sizeof(pg_data_t);
		/* convert size to large (pmd size) pages, rounding up */
		/*
		 * 将这个大小对齐为一个 pmd 表示的虚地址空间大小的倍数(4MB 的倍数)
		 * 使这段用于管理页帧的数据结构的虚地址可以映射在一个或多个PMD中
		 * 并将对应的物理内存作为4MB的巨型页进行映射
		 */
		size = (size + LARGE_PAGE_BYTES - 1) / LARGE_PAGE_BYTES;
		/* now the roundup is correct, convert to PAGE_SIZE pages */
		/* 再将这个数量转换为页帧数*/
		size = size * PTRS_PER_PTE;

		node_remap_size[nid] = size;
		reserve_pages += size;
		node_remap_offset[nid] = reserve_pages;
		/*修改该节点可用的页帧结束编号*/
		node_end_pfn[nid] -= size;
		/*记录由于该节点的内存管理器和页描述符的起始页帧号*/
		node_remap_start_pfn[nid] = node_end_pfn[nid];
	}
	return reserve_pages;
}

/*
 * workaround for Dell systems that neglect to reserve EBDA
 */
static void __init reserve_ebda_region_node(void)
{
	unsigned int addr;
	addr = get_bios_ebda();
	if (addr)
		reserve_bootmem_node(NODE_DATA(0), addr, PAGE_SIZE);
}
/**
 * 1. 获得了内存分布信息
 * 2. 初始化了 NODE 和 相应的内存页帧映射关系
 * 3. pg_data_t 所管理的页 struct page 的数据结构的大小和虚拟地址
 * 4. 确定了直接映射的范围
 * 5. 初始化了启动内存分配器 bootmem
 */
unsigned long __init setup_memory(void)
{
	int nid;
	unsigned long bootmap_size, system_start_pfn, system_max_low_pfn;
	unsigned long reserve_pages/**< 用于页描述符和节点管理区的内存的页面数*/, pfn;

	/*
	 * When mapping a NUMA machine we allocate the node_mem_map arrays
	 * from node local memory.  They are then mapped directly into KVA
	 * between zone normal and vmalloc space.  Calculate the size of
	 * this space and use it to adjust the boundry between ZONE_NORMAL
	 * and ZONE_HIGHMEM.
     *
     * 核心的布局说明：
	 * 当映射一个numa机器时，我们从节点本地内存分配node_mem_map数组。
	 * 他们被映射到直接映射的内核虚拟地址空间中。计算这个空间的大小，并使用
	 * 它去修正ZONE_NORMAL和ZONE_HIGHMEM之间的边界。
     *
     *
     *
     * 获取每个节点的起止页帧号，并初始化节点分布位图
     * 这些页帧不一定都是可用的，要根据 e820.map[] 来确定
     */
	get_memcfg_numa();

	/* Fill in the physnode_map 
     * 将 node id 与 pfn 的对应关系映射到一张一维表中 ，用于node id 与 pfn 之间的转换
     * 假设有2个节点，第一个节点只有256MB的内存，第二个有512MB的内存
     * 两个节点间有256MB的空洞
     * +-------------+-------------+
     * |     cpu 1   |    cpu 2    |
     * +------+------+------+------+
     * |    node 1   |    node 2   | node mapping
     * +------+------+------+------+
     * |  0   |  -1  |   1  |   1  | physnode_map[]
     * +------+------+------+------+
     * 0            ----         max_pfn
     */
	for_each_online_node(nid) {
		for (pfn = node_start_pfn[nid];
                    pfn < node_end_pfn[nid]; pfn += PAGES_PER_ELEMENT) {
			physnode_map[pfn / PAGES_PER_ELEMENT] = nid;
		}
	}
	/*计算管理每个节点（除0号节点描述符）需要的页帧描述符和节点描述符的内存空间，并计算相关的数据*/
	reserve_pages = calculate_numa_remap_pages();
	/* partially used pages are not usable - thus round upwards */
	/* 计算启动后的直接映射的最低页帧号，向上对齐init_pg_tables_end （启动时的最低可用页号）*/
	system_start_pfn = min_low_pfn = PFN_UP(init_pg_tables_end);

	/* 计算最大页帧号 max_pfn，和高端页的数量*/
	find_max_pfn();
	/*
     * 计算启动后直接映射的最高页帧号（除去高端内存的页帧数和内存管理的页帧数），
	 * 最大直接映射的高虚地址用于 NODE 的页描述符和 node 描述符的数据结构内存。
	 * 虽然用于页和页管理的内存物理上不连续，来自各个node的尾部，
	 * 但是都被映射到直接映射区的尾部（0xf8000000向低地址方向）
	 */
	system_max_low_pfn = max_low_pfn = find_max_low_pfn() - reserve_pages;
#ifdef CONFIG_HIGHMEM
	/*高端页框的结束页框一定为最高可用页框*/
	highstart_pfn = highend_pfn = max_pfn;
	/*如果存在高端内存那么条件成立，调整高端页框的起始页框号
	 *只要是非直接映射的可用内存都是高端，即使是用于页帧和节点管理的页（这些页被标记为不可用）*/
	if (highstart_pfn > system_max_low_pfn)
		highstart_pfn = system_max_low_pfn;
#endif
	/*
	 *     src  node_end_pfn[1]
	 *                    | Node1                 Node2             Node3
	 *         +-----------------------------+----------------+-----------------+
	 *         |----------|//////////////////|        |///////|         |///////|
	 *         +----------+------------------+----------------+-----------------+
	 *         |          |node_remap_size[1]|
	 *         |          |pgtable belong this pg_data_t and all of pages can mapping into one pmd
	 * node_start_pfn[1]  |
	 *                    |
	 *     new node_end_pfn[1]
	 *         node_remap_start_pfn[1]
	 *
	 * node_remap_offset[0] = 0
	 * node_remap_offset[1] = 50 number of pages belong to manager data struct of node1
	 * node_remap_offset[2] = 100
	 * node_remap_offset[3] = 150
	 *
     *highstart_pfn+reserve_pages (0xf8000000)  <----+-----------+
     *                                               |   NODE1   |
     *                                               +-----------+ node_remap_start_vaddr[1]
     *                                               |   NODE2   |
     *                                               +-----------+ node_remap_start_vaddr[2]
     *                                               |   NODE3   |
	 *                                               +-----------+ node_remap_start_vaddr[3]
     *                                               |   unused  |
     *                          var:max_low_pfn <----+-----------+----> highstart_pfn
     *                                               |direct  map|
     *                                               |direct  map|
     *                                               |direct  map|
     *                                               |tmp bootmem| used by bootmem alloctor
	 *                          var:min_low_pfn(new)-+-----------+
	 *                                               |   NODE0   | only size of pg_data_t
	 *                              min_low_pfn(old) +-----------+ (pg_data_t *)(__vaddr(min_low_pfn << PAGE_SHIFT))
	 *
	 */
	for_each_online_node(nid) {
		/*将各个节点管理的起始地址从高端虚拟地址向低端虚拟地址的起始地址开始进行连续映射（使用vmalloc的虚拟地址空间）？*/
		node_remap_start_vaddr[nid] = pfn_to_kaddr(
			(highstart_pfn + reserve_pages) - node_remap_offset[nid]);
		/* 分配节点管理的虚拟地址内存，
         * 但是0号节点分配系统最低可用页帧号的指向的虚拟地址，
         * 并调整最低可用页帧号*/
		allocate_pgdat(nid);
	}
	/*一部分虚拟地址空间用于了节点管理空间*/
	vmalloc_earlyreserve = reserve_pages * PAGE_SIZE;

	for_each_online_node(nid) {
        /*调整各个节点的最大页帧号*/
		find_max_pfn_node(nid);
	}
	
	/*将0号节点用于启动内存分配器*/
	NODE_DATA(0)->bdata = &node0_bdata;

	/*
	 * Initialize the boot-time allocator (with low memory only):
     * 将直接映射的页都初始化到 bootmem 内存管理器中
	 */
	bootmap_size = init_bootmem_node(NODE_DATA(0), min_low_pfn, 0, system_max_low_pfn);
	
	/*将可用的页帧号映射到bootmem页帧管理位图中：0表示未分配，1表示已分配*/
	register_bootmem_low_pages(system_max_low_pfn);

	/*
	 * Reserve the bootmem bitmap itself as well. We do this in two
	 * steps (first step was init_bootmem()) because this catches
	 * the (very unlikely) case of us accidentally initializing the
	 * bootmem allocator with an invalid RAM area.
	 * 保留bootmem位图自身。我们分两步进行（第一步是 init_bootmem()），因为这将发现
	 * 我们意外使用无效的物理内存区域初始化bootmem分配器的情况。
	 * 标记一部分不可使用的页帧，包括bootmem的位图部分
	 */
	reserve_bootmem_node(NODE_DATA(0), HIGH_MEMORY, (PFN_PHYS(min_low_pfn) +
		 bootmap_size + PAGE_SIZE-1) - (HIGH_MEMORY));

	/*
	 * reserve physical page 0 - it's a special BIOS page on many boxes,
	 * enabling clean reboots, SMP operation, laptop functions.
	 */
	reserve_bootmem_node(NODE_DATA(0), 0, PAGE_SIZE);

	/*
	 * But first pinch a few for the stack/trampoline stuff
	 * FIXME: Don't need the extra page at 4K, but need to fix
	 * trampoline before removing it. (see the GDT stuff)
	 */
	reserve_bootmem_node(NODE_DATA(0), PAGE_SIZE, PAGE_SIZE);

	/* reserve EBDA region, it's a 4K region */
	reserve_ebda_region_node();

#ifdef CONFIG_ACPI_SLEEP
	/*
	 * Reserve low memory region for sleep support.
	 */
	acpi_reserve_bootmem();
#endif

	/*
	 * Find and reserve possible boot-time SMP configuration:
	 */
	find_smp_config();

#ifdef CONFIG_BLK_DEV_INITRD
	if (LOADER_TYPE && INITRD_START) {
		if (INITRD_START + INITRD_SIZE <= (system_max_low_pfn << PAGE_SHIFT)) {
			reserve_bootmem_node(NODE_DATA(0), INITRD_START, INITRD_SIZE);
			initrd_start =
				INITRD_START ? INITRD_START + PAGE_OFFSET : 0;
			initrd_end = initrd_start+INITRD_SIZE;
		}
		else {
			printk(KERN_ERR "initrd extends beyond end of memory "
			    "(0x%08lx > 0x%08lx)\ndisabling initrd\n",
			    INITRD_START + INITRD_SIZE,
			    system_max_low_pfn << PAGE_SHIFT);
			initrd_start = 0;
		}
	}
#endif
	return system_max_low_pfn;
}

void __init zone_sizes_init(void)
{
	int nid;

	/*
	 * Insert nodes into pgdat_list backward so they appear in order.
	 * Clobber node 0's links and NULL out pgdat_list before starting.
	 */
	/*
	 * 按节点升序将pg_data_t连接到pgdat_list链表中，除node0外，初始化pg_data_t的数据
	 * node0此时还将用于bootmem分配器
	 */
	pgdat_list = NULL;
	for (nid = MAX_NUMNODES - 1; nid >= 0; nid--) {
		if (!node_online(nid))
			continue;
		if (nid)
			memset(NODE_DATA(nid), 0, sizeof(pg_data_t));
		NODE_DATA(nid)->pgdat_next = pgdat_list;
		pgdat_list = NODE_DATA(nid);
	}

	for_each_online_node(nid) {
		unsigned long zones_size[MAX_NR_ZONES] = {0, 0, 0};
		unsigned long *zholes_size;
		unsigned int max_dma;

		unsigned long low = max_low_pfn;
		unsigned long start = node_start_pfn[nid];
		unsigned long high = node_end_pfn[nid];
		
		/*__PAGE_OFFSET 起最多16MB的连续空间可以作为直接映射*/
		max_dma = virt_to_phys((char *)MAX_DMA_ADDRESS) >> PAGE_SHIFT;

		/*根据该节点所持有的页帧起止编号，初始化该节点的各个内存区域中的页帧数*/
		if (start > low) {
#ifdef CONFIG_HIGHMEM
			BUG_ON(start > high);
			/*该NODE上的页帧位于直接映射内存之上*/
			zones_size[ZONE_HIGHMEM] = high - start;
#endif
		} else {
			if (low < max_dma)
				/*直接映射内存小于16MB*/
				zones_size[ZONE_DMA] = low;
			else {
				BUG_ON(max_dma > low);
				BUG_ON(low > high);
				zones_size[ZONE_DMA] = max_dma;
				zones_size[ZONE_NORMAL] = low - max_dma;
#ifdef CONFIG_HIGHMEM
				zones_size[ZONE_HIGHMEM] = high - low;
#endif
			}
		}
		zholes_size = get_zholes_size(nid);
		/*
		 * We let the lmem_map for node 0 be allocated from the
		 * normal bootmem allocator, but other nodes come from the
		 * remapped KVA area - mbligh
		 * 0号节点做特殊处理
		 */
		if (!nid) {
			/*NODE_DATA(0)->node_mem_map == NULL*/
			free_area_init_node(nid, NODE_DATA(nid),
				zones_size, start, zholes_size);
		} else {
			/*
			 * 将保留用于节点管理的内存，前半部分用于管理描述符，后半部分用于页描述符数组，
			 * 该部分内存以及映射到高端内存的起始虚拟地址上。
			 */
			unsigned long lmem_map;
			lmem_map = (unsigned long)node_remap_start_vaddr[nid];
			lmem_map += sizeof(pg_data_t) + PAGE_SIZE - 1;
			lmem_map &= PAGE_MASK;/*向上按页对齐*/
			NODE_DATA(nid)->node_mem_map = (struct page *)lmem_map;
			free_area_init_node(nid, NODE_DATA(nid),
				zones_size, start, zholes_size);
		}
	}
	return;
}

void __init set_highmem_pages_init(int bad_ppro) 
{
#ifdef CONFIG_HIGHMEM
	struct zone *zone;

	for_each_zone(zone) {
		unsigned long node_pfn, node_high_size, zone_start_pfn;
		struct page * zone_mem_map;
		
		if (!is_highmem(zone))
			continue;

		printk("Initializing %s for node %d\n", zone->name,
			zone->zone_pgdat->node_id);
		/*该node管理的页帧属于高端内存*/
		node_high_size = zone->spanned_pages;
		zone_mem_map = zone->zone_mem_map;
		zone_start_pfn = zone->zone_start_pfn;

		for (node_pfn = 0; node_pfn < node_high_size; node_pfn++) {
			one_highpage_init((struct page *)(zone_mem_map + node_pfn),
					  (int)(zone_start_pfn + node_pfn), bad_ppro);
		}
	}
	totalram_pages += totalhigh_pages;
#endif
}

void __init set_max_mapnr_init(void)
{
#ifdef CONFIG_HIGHMEM
	num_physpages = highend_pfn;
#else
	num_physpages = max_low_pfn;
#endif
}
